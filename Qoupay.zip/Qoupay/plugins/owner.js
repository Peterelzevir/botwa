import chalk from 'chalk';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const settings = require('../settings.js');

export default (gisnaxd) => {
    gisnaxd.on('command', async ({ msg, from, command, args, prefix }) => {
        const isOwner = settings.owner.includes(msg.key.participant || msg.key.remoteJid.split('@')[0]);
        
        switch (command) {
            case 'owner':
                await gisnaxd.sendMessage(from, {
                    text: `*👤 Owner Information*\n\n` +
                          `• Name: Qoupay Dev\n` +
                          `• Number: wa.me/6285210868214\n` +
                          `• Bot Name: ${settings.botName}\n\n` +
                          `${settings.footer}`,
                });
                break;
                
            case 'restart':
                if (!isOwner) {
                    await gisnaxd.sendMessage(from, { text: '❌ This command is only for the owner!' });
                    return;
                }
                await gisnaxd.sendMessage(from, { text: '🔄 Restarting bot...' });
                process.exit(1);
                break;
                
            case 'broadcast':
                if (!isOwner) {
                    await gisnaxd.sendMessage(from, { text: '❌ This command is only for the owner!' });
                    return;
                }
                if (!args.length) {
                    await gisnaxd.sendMessage(from, { text: '❌ Please provide a message to broadcast!' });
                    return;
                }
                break;
        }
    });
    
    console.log(chalk.green('✅ Owner plugin loaded'));
};