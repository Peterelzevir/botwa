// settings.js
module.exports = {
    owner: ['6285210868214'],
    prefix: ['/', '.', '!', '#'],
    botName: 'Qoupay Bot',
    footer: '© 2025 Qoupay Dev',
    apiKey: 'YOUR_API_KEY', // kli butuh gitu buat fitur fitur butuh apikey
};